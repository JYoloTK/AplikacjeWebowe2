<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('hello'); #default action
//App::getRouter()->setLoginRoute('login'); #action to forward if no permissions
App::getRouter()->setLoginRoute('accessdenied'); #action to forward if no permissions

Utils::addRoute('hello', 'HelloCtrl');
Utils::addRoute('accessdenied', 'HelloCtrl');

Utils::addRoute('logowanie', 'Logowanie');
Utils::addRoute('swiat', 'TworzenieSwiata',["admin"]);
Utils::addRoute('postac', 'TworzeniePostaci');
Utils::addRoute('lokacja', 'TworzenieLokacji');
Utils::addRoute('npc', 'TworzenieNPC');
Utils::addRoute('potwor', 'TworzeniePotwora');
Utils::addRoute('system', 'DodawanieSystemu');

Utils::addRoute('lista_postaci', 'ListaPostaci');
Utils::addRoute('lista_lokacji', 'ListaLokacji');
Utils::addRoute('lista_npc', 'ListaNPC');
Utils::addRoute('lista_potworow', 'ListaPotworow');

//Utils::addRoute('tabela_dodaj1', 'TestowaTabela');