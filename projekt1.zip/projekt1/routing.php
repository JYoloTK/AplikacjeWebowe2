<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('hello'); #default action
//App::getRouter()->setLoginRoute('login'); #action to forward if no permissions
App::getRouter()->setLoginRoute('accessdenied'); #action to forward if no permissions

Utils::addRoute('hello', 'HelloCtrl');
Utils::addRoute('accessdenied', 'HelloCtrl');

Utils::addRoute('loginShow', 'Logowanie');
Utils::addRoute('login', 'Logowanie');
Utils::addRoute('logout', 'Logowanie');
Utils::addRoute('swiat', 'TworzenieSwiata', ["admin","GM"]);
Utils::addRoute('postacSave', 'TworzeniePostaci');
Utils::addRoute('postacNew', 'TworzeniePostaci', ["admin","user"]);
Utils::addRoute('postacEdit', 'TworzeniePostaci', ["admin","user"]);
Utils::addRoute('postacDelete', 'TworzeniePostaci', ["admin","user"]);
Utils::addRoute('lokacjaSave', 'TworzenieLokacji');
Utils::addRoute('lokacjaNew', 'TworzenieLokacji', ["admin","GM"]);
Utils::addRoute('lokacjaEdit', 'TworzenieLokacji', ["admin","GM"]);
Utils::addRoute('lokacjaDelete', 'TworzenieLokacji', ["admin","GM"]);
Utils::addRoute('npcSave', 'TworzenieNPC');
Utils::addRoute('npcNew', 'TworzenieNPC', ["admin","GM"]);
Utils::addRoute('npcEdit', 'TworzenieNPC', ["admin","GM"]);
Utils::addRoute('npcDelete', 'TworzenieNPC', ["admin","GM"]);
Utils::addRoute('potworSave', 'TworzeniePotwora');
Utils::addRoute('potworNew', 'TworzeniePotwora', ["admin","GM"]);
Utils::addRoute('potworEdit', 'TworzeniePotwora', ["admin","GM"]);
Utils::addRoute('potworDelete', 'TworzeniePotwora', ["admin","GM"]);

Utils::addRoute('lista_postaci', 'ListaPostaci');
Utils::addRoute('lista_lokacji', 'ListaLokacji');
Utils::addRoute('lista_npc', 'ListaNPC');
Utils::addRoute('lista_potworow', 'ListaPotworow');

//Utils::addRoute('tabela_dodaj1', 'TestowaTabela');