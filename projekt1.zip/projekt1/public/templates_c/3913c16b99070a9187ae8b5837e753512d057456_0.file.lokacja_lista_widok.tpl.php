<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:51:21
  from 'C:\xampp\htdocs\projekt1\app\views\lokacja_lista_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e76d9eedda2_87254661',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3913c16b99070a9187ae8b5837e753512d057456' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\lokacja_lista_widok.tpl',
      1 => 1654552277,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e76d9eedda2_87254661 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_59093445629e76d9ed9f81_08582164', 'mid');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_59093445629e76d9ed9f81_08582164 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_59093445629e76d9ed9f81_08582164',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<section class="wrapper style5">
<div class="inner">
    <div class="buttons">
        <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lokacjaNew">Dodaj nową lokację</a>
    </div>
    <br>
    <h4>Lista lokacji</h4>
<table cellpadding="5">
<thead>
	<tr>
		<th>Nazwa</th>
		<th>Powierzchnia</th>
		<th>Biom</th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'wiersz');
$_smarty_tpl->tpl_vars['wiersz']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['wiersz']->value) {
$_smarty_tpl->tpl_vars['wiersz']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwalokacja"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["wielkosc"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["biom"];?>
</td><td><a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
lokacjaEdit/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['nazwalokacja'];?>
">Edytuj</a>&nbsp;<a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
lokacjaDelete/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['nazwalokacja'];?>
">Usuń</a></td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table>
</div>
</section>
<?php
}
}
/* {/block 'mid'} */
}
