<?php
/* Smarty version 4.1.0, created on 2022-05-30 21:11:49
  from 'C:\xampp\htdocs\projekt1\app\views\swiat_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629516f5e6c9b4_50184457',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '22ac3fd3be0850f7b1f456da396710cb20123c59' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\swiat_widok.tpl',
      1 => 1653937845,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629516f5e6c9b4_50184457 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_456559490629516f5e6bad6_80797926', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_456559490629516f5e6bad6_80797926 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_456559490629516f5e6bad6_80797926',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
                                                            <section>
								<h3>Tworzenie Świata</h3>
                                                            </section>
                                                            <h5>Funkcja tymczasowa nieaktywna</h5>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
