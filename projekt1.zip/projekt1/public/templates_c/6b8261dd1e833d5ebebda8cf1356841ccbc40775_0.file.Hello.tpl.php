<?php
/* Smarty version 4.1.0, created on 2022-05-17 08:10:41
  from 'C:\xampp\Nowy folder\htdocs\projekt1\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62833c610fb674_69685186',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b8261dd1e833d5ebebda8cf1356841ccbc40775' => 
    array (
      0 => 'C:\\xampp\\Nowy folder\\htdocs\\projekt1\\app\\views\\Hello.tpl',
      1 => 1652715628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62833c610fb674_69685186 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_173603723562833c610fa5c5_63224885', 'mid');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_173603723562833c610fa5c5_63224885 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_173603723562833c610fa5c5_63224885',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


				<!-- Main -->
					<article id="main">
						<header>
							<h2>Bukszpan</h2>
							<p>kolos srolos</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">
								<h4>Logowanie</h4>
									<form method="post" action="#">
										<div class="row gtr-uniform">
											<div class="col-6 col-12-xsmall">
												<input type="text" id="id_login" value="" placeholder="Login" />
											</div>
											<div class="col-6 col-12-xsmall">
												<input type="password" id="id_password" value="" placeholder="Hasło" />
											</div>
										</div>
                                                                        </form>
							</div>	
						</section>
					</article>

<?php
}
}
/* {/block 'mid'} */
}
