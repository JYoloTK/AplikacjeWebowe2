<?php
/* Smarty version 4.1.0, created on 2022-05-31 00:09:56
  from 'C:\xampp\htdocs\projekt1\app\views\templates\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629540b426fbc8_21819002',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9fb8588b016829ea69e818c64df2be0705fa72f4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\templates\\main.tpl',
      1 => 1653947557,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629540b426fbc8_21819002 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="pl">

<head>
	<title>Paper RPG</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/main.css" />
	<noscript><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
    		<!-- Page Wrapper -->
			<div id="page-wrapper">

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_398305292629540b424f581_91115182', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1577624345629540b4253ea9_21180904', 'messages');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_970258196629540b426ee05_50191140', 'mid');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_522167950629540b426f528_57463968', 'bottom');
?>


</body>

</html><?php }
/* {block 'top'} */
class Block_398305292629540b424f581_91115182 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_398305292629540b424f581_91115182',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 
				<!-- Header -->
					<header id="header">
						<h1><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
Hello" class="pure-menu-heading pure-menu-link">Paper RPG</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>

											<li>Menu</li>
											<li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logowanie" class="pure-menu-heading pure-menu-link">Zaloguj się</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
swiat" class="pure-menu-heading pure-menu-link">Stwórz świat</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postacNew" class="pure-menu-heading pure-menu-link">Stwórz postać</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lokacjaNew" class="pure-menu-heading pure-menu-link">Stwórz lokacje</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
npcNew" class="pure-menu-heading pure-menu-link">Stwórz NPC</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
potworNew" class="pure-menu-heading pure-menu-link">Stwórz potwora</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
system" class="pure-menu-heading pure-menu-link">Dodaj system</a></li>
                                                                                        <li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_postaci" class="pure-menu-heading pure-menu-link">Lista postaci</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_lokacji" class="pure-menu-heading pure-menu-link">Lista lokacji</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_npc" class="pure-menu-heading pure-menu-link">Lista NPC</a>
                                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_potworow" class="pure-menu-heading pure-menu-link">Lista potworów</a></li>
                                                                                        <li><a href="#" class="pure-menu-heading pure-menu-link">Wyloguj się</a></li>
                                                                                        
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</header>
<?php
}
}
/* {/block 'top'} */
/* {block 'messages'} */
class Block_1577624345629540b4253ea9_21180904 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_1577624345629540b4253ea9_21180904',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
<section class="wrapper style3">
<div class="inner">
	<ul class="alt">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
	<li style="color:#ffffa0" class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ul>
</div>
</section>
<?php }?>

<?php
}
}
/* {/block 'messages'} */
/* {block 'mid'} */
class Block_970258196629540b426ee05_50191140 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_970258196629540b426ee05_50191140',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'mid'} */
/* {block 'bottom'} */
class Block_522167950629540b426f528_57463968 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_522167950629540b426f528_57463968',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Footer -->
					<footer id="footer">
						<ul class="icons">
							<li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
							<li><a href="#" class="icon brands fa-dribbble"><span class="label">Dribbble</span></a></li>
							<li><a href="#" class="icon solid fa-envelope"><span class="label">Email</span></a></li>
						</ul>
						<ul class="copyright">
							<li>&copy; Untitled</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</footer>

			</div>

		<!-- Scripts -->
			<?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrollex.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrolly.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/browser.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/util.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/main.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'bottom'} */
}
