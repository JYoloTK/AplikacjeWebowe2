<?php
/* Smarty version 4.1.0, created on 2022-06-05 18:42:13
  from 'C:\xampp\htdocs\projekt1\app\views\logowanie_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629cdce5623df6_15127886',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eaf6f17616de685e746de9b960462c9dc9191e55' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\logowanie_widok.tpl',
      1 => 1654447331,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629cdce5623df6_15127886 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_882374249629cdce5616924_25540672', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_882374249629cdce5616924_25540672 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_882374249629cdce5616924_25540672',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
<section class="wrapper style5">
<div class="inner">    
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
login" method="post">
	<fieldset>
            <h3>Zaloguj się</h3>
            <div class="row gtr-uniform">
                <div class="col-12">
			<input id="login" type="text" placeholder="Login" name="login" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->login;?>
">
		</div>
                <div class="col-12">
			<input id="haslo" type="password" placeholder="Hasło" name="haslo" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->haslo;?>
">
		</div>
		<div class="actions">
                    <input type="submit" class="button primary" value="Zaloguj"/>
		</div>
            </div>
	</fieldset>
</form>
</div>       
</section>                
                                 
<?php
}
}
/* {/block 'mid'} */
}
