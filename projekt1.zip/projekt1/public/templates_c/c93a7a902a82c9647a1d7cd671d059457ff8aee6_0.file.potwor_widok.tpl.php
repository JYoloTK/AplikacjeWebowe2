<?php
/* Smarty version 4.1.0, created on 2022-05-30 20:54:15
  from 'C:\xampp\htdocs\projekt1\app\views\potwor_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629512d75bc8a1_78530706',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c93a7a902a82c9647a1d7cd671d059457ff8aee6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\potwor_widok.tpl',
      1 => 1653936853,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629512d75bc8a1_78530706 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1593965364629512d75a4d21_29097732', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1593965364629512d75a4d21_29097732 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1593965364629512d75a4d21_29097732',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
potworSave" method="post">
	<fieldset>
            <h3>Stwórz potwora</h3>
            <div class="row gtr-uniform">
		<div class="col-12">
                    <input id="rasa" type="text" placeholder="Rasa" name="rasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->rasa;?>
">
                </div>
                <div class="col-12">
                    <input id="idlokacja" type="text" placeholder="ID Lokacji" name="idlokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idlokacja;?>
">
                </div>
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    <input type="hidden" name="idpotwor" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idpotwor;?>
">
</form>	
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
