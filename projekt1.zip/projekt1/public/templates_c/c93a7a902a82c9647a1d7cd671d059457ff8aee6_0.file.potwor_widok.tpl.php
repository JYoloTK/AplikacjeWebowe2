<?php
/* Smarty version 4.1.0, created on 2022-05-24 09:03:42
  from 'C:\xampp\htdocs\projekt1\app\views\potwor_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628c834ed446c5_41739989',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c93a7a902a82c9647a1d7cd671d059457ff8aee6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\potwor_widok.tpl',
      1 => 1652771318,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628c834ed446c5_41739989 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_448946962628c834ed43ce0_87913481', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_448946962628c834ed43ce0_87913481 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_448946962628c834ed43ce0_87913481',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Tworzenie Potwora</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="potwor_rasa" value="" placeholder="Rasa" />
                                                                    </div>
                                                                    <li><a href="#stworzono_potwora" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
