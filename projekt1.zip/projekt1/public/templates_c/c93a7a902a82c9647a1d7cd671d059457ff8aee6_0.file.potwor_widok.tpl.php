<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:46:19
  from 'C:\xampp\htdocs\projekt1\app\views\potwor_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e75abecac39_75766680',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c93a7a902a82c9647a1d7cd671d059457ff8aee6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\potwor_widok.tpl',
      1 => 1654551976,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e75abecac39_75766680 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1490818351629e75abec4a23_42935751', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1490818351629e75abec4a23_42935751 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1490818351629e75abec4a23_42935751',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
potworSave" method="post">
	<fieldset>
            <h3>Stwórz potwora</h3>
            <div class="row gtr-uniform">
		<div class="col-12">
                    <input id="rasa" type="text" placeholder="Rasa" name="rasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->rasa;?>
">
                </div>
                <div class="col-12">
                    <input id="nazwalokacja" type="text" placeholder="Nazwa Lokacji" name="nazwalokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwalokacja;?>
">
                </div>
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    <input type="hidden" name="idpotwor" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idpotwor;?>
">
</form>
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
