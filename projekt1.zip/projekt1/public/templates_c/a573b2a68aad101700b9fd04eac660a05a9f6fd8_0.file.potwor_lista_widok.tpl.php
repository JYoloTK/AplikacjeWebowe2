<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:46:26
  from 'C:\xampp\htdocs\projekt1\app\views\potwor_lista_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e75b2361340_94996192',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a573b2a68aad101700b9fd04eac660a05a9f6fd8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\potwor_lista_widok.tpl',
      1 => 1654551961,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e75b2361340_94996192 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1772606919629e75b2353ba5_05705351', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1772606919629e75b2353ba5_05705351 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1772606919629e75b2353ba5_05705351',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<section class="wrapper style5">
<div class="inner">
    <div class="buttons">
        <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
potworNew">Dodaj nowego potwora</a>
    </div>
    <br>
    <h4>Lista potworów</h4>
<table cellpadding="5">
<thead>
	<tr>
		<th>ID</th>
		<th>Rasa</th>
		<th>Nazwa Lokacji</th>
	</tr>
</thead>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'wiersz');
$_smarty_tpl->tpl_vars['wiersz']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['wiersz']->value) {
$_smarty_tpl->tpl_vars['wiersz']->do_else = false;
?>
<tr>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["idpotwor"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["rasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwalokacja"];?>
</td>
  <td>
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
potworEdit/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idpotwor'];?>
">Edytuj</a>
	&nbsp;
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
potworDelete/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idpotwor'];?>
">Usuń</a>
    </td>
</tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
</div>
</section>

<?php
}
}
/* {/block 'mid'} */
}
