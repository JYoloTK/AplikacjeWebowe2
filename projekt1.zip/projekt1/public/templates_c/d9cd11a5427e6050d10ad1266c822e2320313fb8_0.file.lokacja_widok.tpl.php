<?php
/* Smarty version 4.1.0, created on 2022-05-30 22:24:22
  from 'C:\xampp\htdocs\projekt1\app\views\lokacja_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629527f68fc586_77432252',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9cd11a5427e6050d10ad1266c822e2320313fb8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\lokacja_widok.tpl',
      1 => 1653942259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629527f68fc586_77432252 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_354160586629527f68f6150_98939775', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_354160586629527f68f6150_98939775 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_354160586629527f68f6150_98939775',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lokacjaSave" method="post">
	<fieldset>
            <h3>Stwórz lokacje</h3>
            <div class="row gtr-uniform">
		<div class="col-12">
                    <input id="nazwa" type="text" placeholder="Nazwa" name="nazwa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwa;?>
">
                </div>                                                                                    
                <div class="col-12">
                    <select id="wielkosc" type="text" name="wielkosc" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->wielkosc;?>
">
                            <option>Bardzo mała</option>
                            <option>Mała</option>
                            <option>Średnia</option>
                            <option>Spora</option>
                            <option>Duża</option>
                            <option>Bardzo duża</option>
                            <option>Ogromna</option>
                            <option>Gigantyczna</option>
                    </select>
                </div>
                <div class="col-12">
                    <input id="biom" type="text" placeholder="Biom" name="biom" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->biom;?>
">
                </div>      
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    <input type="hidden" name="idlokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idlokacja;?>
">
</form>	
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
