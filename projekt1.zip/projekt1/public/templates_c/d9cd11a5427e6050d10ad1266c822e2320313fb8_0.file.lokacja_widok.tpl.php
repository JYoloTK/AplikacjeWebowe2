<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:31:18
  from 'C:\xampp\htdocs\projekt1\app\views\lokacja_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e722682b512_83903929',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9cd11a5427e6050d10ad1266c822e2320313fb8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\lokacja_widok.tpl',
      1 => 1654551072,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e722682b512_83903929 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_788545465629e7226825e48_35283791', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_788545465629e7226825e48_35283791 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_788545465629e7226825e48_35283791',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lokacjaSave" method="post">
	<fieldset>
            <h3>Stwórz lokacje</h3>
            <div class="row gtr-uniform">
		<div class="col-12">
                    <input id="nazwalokacja" type="text" placeholder="Nazwa" name="nazwalokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwalokacja;?>
">
                </div>                                                                                    
                <div class="col-12">
                    <select id="wielkosc" type="text" name="wielkosc" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->wielkosc;?>
">
                            <option>Bardzo mała</option>
                            <option>Mała</option>
                            <option>Średnia</option>
                            <option>Spora</option>
                            <option>Duża</option>
                            <option>Bardzo duża</option>
                            <option>Ogromna</option>
                            <option>Gigantyczna</option>
                    </select>
                </div>
                <div class="col-12">
                    <input id="biom" type="text" placeholder="Biom" name="biom" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->biom;?>
">
                </div>      
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    </form>	
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
