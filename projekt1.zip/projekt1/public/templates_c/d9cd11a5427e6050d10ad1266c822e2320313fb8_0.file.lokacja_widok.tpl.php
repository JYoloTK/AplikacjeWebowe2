<?php
/* Smarty version 4.1.0, created on 2022-05-16 16:46:22
  from 'C:\xampp\htdocs\projekt1\app\views\lokacja_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628263be76f129_07197035',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9cd11a5427e6050d10ad1266c822e2320313fb8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\lokacja_widok.tpl',
      1 => 1652712376,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628263be76f129_07197035 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_276185275628263be76e786_04514962', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_276185275628263be76e786_04514962 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_276185275628263be76e786_04514962',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Tworzenie Lokacji</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="lokacja_nazwa" value="" placeholder="Nazwa" />
                                                                    </div>
                                                                    <div class="col-12">
									<select id="lokacja_wielkosc">
										<option value="">Wybierz skalę</option>
										<option value="1">Bardzo mała (pokój)</option>
										<option value="1">Mała (dom mieszkalny)</option>
										<option value="1">Średnia (spory budynek)</option>
                                                                                <option value="1">Spora (ulica)</option>
                                                                                <option value="1">Duża (wioska)</option>
                                                                                <option value="1">Bardzo duża (miasto)</option>
                                                                                <option value="1">Ogromna (region)</option>
                                                                                <option value="1">Gigantyczna (kraina)</option>
									</select>
                                                                    </div>
                                                                    <div class="col-12">
                                                                    <input type="text" id="lokacja_biom" value="" placeholder="Biom" />
                                                                    </div>
                                                                    <li><a href="#stworzono_lokacje" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
