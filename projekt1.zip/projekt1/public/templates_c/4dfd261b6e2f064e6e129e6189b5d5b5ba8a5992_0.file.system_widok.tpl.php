<?php
/* Smarty version 4.1.0, created on 2022-05-30 21:11:44
  from 'C:\xampp\htdocs\projekt1\app\views\system_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629516f09155c6_58029875',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4dfd261b6e2f064e6e129e6189b5d5b5ba8a5992' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\system_widok.tpl',
      1 => 1653937902,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629516f09155c6_58029875 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_149913637629516f0914a36_25768702', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_149913637629516f0914a36_25768702 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_149913637629516f0914a36_25768702',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Dodawanie Systemu</h3>
								</section>
                                                            <h5>Funkcja tymczasowo nieaktywna</h5>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
