<?php
/* Smarty version 4.1.0, created on 2022-05-22 15:14:41
  from 'C:\xampp\htdocs\projekt1\app\views\system_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628a37419cc875_54521509',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4dfd261b6e2f064e6e129e6189b5d5b5ba8a5992' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\system_widok.tpl',
      1 => 1652771350,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628a37419cc875_54521509 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1787382345628a37419cbd55_00668240', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1787382345628a37419cbd55_00668240 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1787382345628a37419cbd55_00668240',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Dodawanie Systemu</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="system_nazwa" value="" placeholder="Nazwa systemu" />
                                                                    </div>
                                                                    <li><a href="#dodano_system" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
