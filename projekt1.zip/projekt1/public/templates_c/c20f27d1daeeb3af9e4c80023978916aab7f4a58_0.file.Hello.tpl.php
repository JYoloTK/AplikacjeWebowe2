<?php
/* Smarty version 4.1.0, created on 2022-06-05 18:37:52
  from 'C:\xampp\htdocs\projekt1\app\views\Hello.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629cdbe07106d7_31730204',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c20f27d1daeeb3af9e4c80023978916aab7f4a58' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\Hello.tpl',
      1 => 1654447069,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629cdbe07106d7_31730204 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1156235276629cdbe070a3b3_55467712', 'mid');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1156235276629cdbe070a3b3_55467712 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1156235276629cdbe070a3b3_55467712',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


				<!-- Main -->
					<article id="main">
						<header>
							<h2>KREATOR DND</h2>
							<p>Twórz swoje własne posctacie, lokacje, npc i potwory!</p>
						</header>
						<section class="wrapper style5">
							<div class="inner">
								<h4>Zaloguj się aby zacząć tworzyć</h4>
								<div class="row gtr-uniform">
                                                                    <ul class="buttons">
                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
loginShow" class="button primary">Zaloguj się</a>
                                                                    </ul>
								</div>
                                                                <h4>Lub wyświetl listę:</h4>
                                                                <div class="row gtr-uniform">
                                                                    <ul class="buttons">
                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_lokacji" class="button">Lokacji</a>
                                                                        <br><br>
                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_postaci" class="button">Postaci</a>
                                                                        <br><br>
                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_npc" class="button">NPC</a>
                                                                        <br><br>
                                                                        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
lista_potworow" class="button">Potworów</a>
                                                                    </ul>
                                                                </div>
							</div>	
						</section>
					</article>

<?php
}
}
/* {/block 'mid'} */
}
