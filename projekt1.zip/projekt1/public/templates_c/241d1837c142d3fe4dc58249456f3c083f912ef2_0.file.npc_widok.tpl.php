<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:43:57
  from 'C:\xampp\htdocs\projekt1\app\views\npc_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e751d9b8124_73526863',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '241d1837c142d3fe4dc58249456f3c083f912ef2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\npc_widok.tpl',
      1 => 1654551833,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e751d9b8124_73526863 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1773427066629e751d9b1c81_52068454', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1773427066629e751d9b1c81_52068454 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1773427066629e751d9b1c81_52068454',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
npcSave" method="post">
	<fieldset>
            <h3>Stwórz npc</h3>
            <div class="row gtr-uniform">
                <div class="col-12">
                    <input id="nazwa" type="text" placeholder="Nazwa" name="nazwa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwa;?>
">
                </div>
		<div class="col-12">
                    <input id="rasa" type="text" placeholder="Rasa" name="rasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->rasa;?>
">
                </div>
                <div class="col-12">
                    <input id="nazwalokacja" type="text" placeholder="Nazwa Lokacji" name="nazwalokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwalokacja;?>
">
                </div>
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    <input type="hidden" name="idnpc" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idnpc;?>
">
</form>	
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
