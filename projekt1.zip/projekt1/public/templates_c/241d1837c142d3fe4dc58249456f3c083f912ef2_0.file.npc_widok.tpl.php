<?php
/* Smarty version 4.1.0, created on 2022-05-16 17:20:40
  from 'C:\xampp\htdocs\projekt1\app\views\npc_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62826bc88f3342_07093481',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '241d1837c142d3fe4dc58249456f3c083f912ef2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\npc_widok.tpl',
      1 => 1652714435,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62826bc88f3342_07093481 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20900881262826bc88f2823_82088735', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_20900881262826bc88f2823_82088735 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_20900881262826bc88f2823_82088735',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

				<!-- Main -->
					<article id="main">
						<section class="wrapper style5">
							<div class="inner">
								<section>
									<h3>Tworzenie NPC</h3>
								</section>
                                                            <section>
                                                                <div class="row gtr-uniform">
                                                                    <div class="col-12">
                                                                    <input type="text" id="npc_nazwa" value="" placeholder="Nazwa" />
                                                                    </div>
                                                                    <div class="col-12">
                                                                    <input type="text" id="npc_rasa" value="" placeholder="Rasa" />
                                                                    </div>
                                                                    <li><a href="#stworzono_npc" class="button primary">Stwórz</a></li>
                                                                </div>
                                                            </section>
							</div>
						</section>
					</article>
<?php
}
}
/* {/block 'mid'} */
}
