<?php
/* Smarty version 4.1.0, created on 2022-06-06 23:41:59
  from 'C:\xampp\htdocs\projekt1\app\views\npc_lista_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e74a70ceed8_73474341',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3475bba06817cd060bc5e4f7826e2ed0de773434' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\npc_lista_widok.tpl',
      1 => 1654551713,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e74a70ceed8_73474341 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1200106768629e74a70c0ed4_42689103', 'mid');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_1200106768629e74a70c0ed4_42689103 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_1200106768629e74a70c0ed4_42689103',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
<section class="wrapper style5">
<div class="inner">
    <div class="buttons">
        <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
npcNew">Dodaj nowego npc</a>
    </div>
    <br>
    <h4>Lista npc</h4>
<table cellpadding="5">
<thead>
	<tr>
		<th>ID</th>
		<th>Nazwa</th>
		<th>Rasa</th>
		<th>Lokacja</th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'wiersz');
$_smarty_tpl->tpl_vars['wiersz']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['wiersz']->value) {
$_smarty_tpl->tpl_vars['wiersz']->do_else = false;
?>
<tr>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["idnpc"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["rasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwalokacja"];?>
</td>
    <td>
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
npcEdit/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idnpc'];?>
">Edytuj</a>
	&nbsp;
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
npcDelete/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idnpc'];?>
">Usuń</a>
    </td>
</tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
</div>
</section>

<?php
}
}
/* {/block 'mid'} */
}
