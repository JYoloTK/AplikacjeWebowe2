<?php
/* Smarty version 4.1.0, created on 2022-06-07 00:08:23
  from 'C:\xampp\htdocs\projekt1\app\views\postac_lista_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629e7ad791ab50_62379099',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0fbadaa99fba3ea297511bfaaa3aa3423da6673c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\postac_lista_widok.tpl',
      1 => 1654553300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629e7ad791ab50_62379099 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_844144403629e7ad7901e06_17853403', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_844144403629e7ad7901e06_17853403 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_844144403629e7ad7901e06_17853403',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
    <div class="buttons">
        <a class="button primary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postacNew">Dodaj nową postać</a>
    </div>
    <br>
    <h4>Lista postaci</h4>
<table cellpadding="5">
<thead>
	<tr>
		<th>ID</th>
		<th>Nazwa</th>
		<th>Rasa</th>
		<th>Klassa</th>
                <th>Level</th>
                <th>Wiek</th>
                <th>Użytkownik</th>
                <th>Lokacja</th>
	</tr>
</thead>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'wiersz');
$_smarty_tpl->tpl_vars['wiersz']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['wiersz']->value) {
$_smarty_tpl->tpl_vars['wiersz']->do_else = false;
?>
<tr>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["idpostac"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["rasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["klasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["level"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["wiek"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["login"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwalokacja"];?>
</td>
    <td>
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
postacEdit/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idpostac'];?>
">Edytuj</a>
	&nbsp;
    <a class="button" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
postacDelete/<?php echo $_smarty_tpl->tpl_vars['wiersz']->value['idpostac'];?>
">Usuń</a>
    </td>
</tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
</div>
</section>

<?php
}
}
/* {/block 'mid'} */
}
