<?php
/* Smarty version 4.1.0, created on 2022-05-24 09:07:36
  from 'C:\xampp\htdocs\projekt1\app\views\postac_lista_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628c84387d0417_50688973',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0fbadaa99fba3ea297511bfaaa3aa3423da6673c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\postac_lista_widok.tpl',
      1 => 1653375885,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628c84387d0417_50688973 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_825421910628c84387c21e8_80231850', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_825421910628c84387c21e8_80231850 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_825421910628c84387c21e8_80231850',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<a class="pure-button button-success" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postac">Tutaj będzie można dodać nową postać</a>
</div>	
    
    
<section class="wrapper style5">
<div class="inner">
    <h4>Lista postaci</h4>
<table cellpadding="5">
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'wiersz');
$_smarty_tpl->tpl_vars['wiersz']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['wiersz']->value) {
$_smarty_tpl->tpl_vars['wiersz']->do_else = false;
?>
<tr>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["id postaci"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["nazwa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["rasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["klasa"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["level"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["wiek"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["id użytkownika"];?>
</td>
  <td><?php echo $_smarty_tpl->tpl_vars['wiersz']->value["id lokacji"];?>
</td>
</tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
</div>
</section>

<?php
}
}
/* {/block 'mid'} */
}
