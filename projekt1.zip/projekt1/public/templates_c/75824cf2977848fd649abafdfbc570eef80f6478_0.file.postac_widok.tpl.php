<?php
/* Smarty version 4.1.0, created on 2022-05-31 00:09:58
  from 'C:\xampp\htdocs\projekt1\app\views\postac_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_629540b6a9e701_10163604',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75824cf2977848fd649abafdfbc570eef80f6478' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\postac_widok.tpl',
      1 => 1653948571,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629540b6a9e701_10163604 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_678096856629540b6a90635_85850506', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_678096856629540b6a90635_85850506 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_678096856629540b6a90635_85850506',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postacSave" method="post">
	<fieldset>
            <h3>Stwórz postać</h3>
            <div class="row gtr-uniform">
                <div class="col-12">
                    <input id="nazwa" type="text" placeholder="Nazwa" name="nazwa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwa;?>
">
                </div>
                <div class="col-12">
                    <input id="rasa" type="text" placeholder="Rasa" name="rasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->rasa;?>
">
                </div>
                <div class="col-12">
                    <input id="klasa" type="text" placeholder="Klasa" name="klasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->klasa;?>
">
                </div>
                <div class="col-12">
                    <input id="level" type="text" placeholder="Level" name="level" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->level;?>
">
                </div>
		<div class="col-12">
                    <input id="wiek" type="text" placeholder="Wiek" name="wiek" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->wiek;?>
">
                </div>
                <div class="col-12">
                    <input id="idlokacja" type="text" placeholder="ID Lokacji" name="idlokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idlokacja;?>
">
                </div>
                <div class="col-12">
                    <input id="iduser" type="text" placeholder="ID Użytkownika" name="iduser" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->iduser;?>
">
                </div>
		<div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
		</div>
            </div>
	</fieldset>
    <input type="hidden" name="idpostac" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idpostac;?>
">
</form>	
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
