<?php
/* Smarty version 4.1.0, created on 2022-06-10 15:38:19
  from 'C:\xampp\htdocs\projekt1\app\views\postac_widok.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62a3494b61e173_81779897',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75824cf2977848fd649abafdfbc570eef80f6478' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt1\\app\\views\\postac_widok.tpl',
      1 => 1654868271,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62a3494b61e173_81779897 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_110831573962a3494b616cd1_13276691', 'mid');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'mid'} */
class Block_110831573962a3494b616cd1_13276691 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'mid' => 
  array (
    0 => 'Block_110831573962a3494b616cd1_13276691',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<section class="wrapper style5">
<div class="inner">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
postacSave" method="post">
	<fieldset>
            <h3>Stwórz postać</h3>
            <div class="row gtr-uniform">
                <div class="actions">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
postacLokacja" class="button primary">Wybierz Lokację</a>
                </div>
                <br>
                <div class="col-12">
                    <input id="nazwa" type="text" placeholder="Nazwa" name="nazwa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwa;?>
">
                </div>
                <div class="col-12">
                    <input id="rasa" type="text" placeholder="Rasa" name="rasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->rasa;?>
">
                </div>
                <div class="col-12">
                    <input id="klasa" type="text" placeholder="Klasa" name="klasa" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->klasa;?>
">
                </div>
                <div class="col-12">
                    <input id="level" type="text" placeholder="Level" name="level" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->level;?>
">
                </div>
		<div class="col-12">
                    <input id="wiek" type="text" placeholder="Wiek" name="wiek" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->wiek;?>
">
                </div>
                <div class="col-12">
                    <input type="hidden" name="idlokacja" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idlokacja;?>
">
                    <h5>Wbrana lokacja: <?php echo $_smarty_tpl->tpl_vars['form']->value->nazwalokacja;?>
</h5>
                </div>
                <div class="actions">
                    <input type="submit" class="button primary" value="Stwórz"/>
                </div>
            </div>
        </fieldset>
    <input type="hidden" name="idpostac" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->idpostac;?>
">
</form>
</div>
</section>    
    
<?php
}
}
/* {/block 'mid'} */
}
