<?php

namespace app\controllers;
use core\App;
use app\forms\TestowaTabelaForm;

class TestowaTabela {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->form = new TestowaTabelaForm();
    }
        
  public function generate_View() {
    $records = App::getDB()->select("user", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("tabela_widok.tpl");
  }

//  public function action_tabela_utworz() {
//  App::getDB()->insert("user",[
//  1 => $iduser,
//  "user1" => $login,
//  "user1" => $haslo,
//  "user" => $rola
// ]);
//  }
//  
  
}