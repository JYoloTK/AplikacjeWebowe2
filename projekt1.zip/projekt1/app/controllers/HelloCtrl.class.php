<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;

class HelloCtrl {
    
    public function action_hello() {
		        
        $variable = 123;
        
        App::getSmarty()->assign("value",$variable);        
        App::getSmarty()->display("Hello.tpl");
        
    }
    
    public function action_accessdenied() {
	      
        Utils::addInfoMessage('Musisz się zalogować aby wykonać tę akcje');
        Utils::addInfoMessage('Musisz się zalogować');
        Utils::addWarningMessage('Musisz');
        Utils::addErrorMessage('error');
        App::getSmarty()->display("logowanie_widok.tpl");
        
    }
}
