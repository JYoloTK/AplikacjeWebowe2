<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ListaLokacjiForm;

class TworzenieLokacji {

    private $form;
    
    public function __construct() {
        $this->form = new ListaLokacjiForm();
    }

    public function validateSave() {
        $this->form->nazwalokacja = ParamUtils::getFromPost('nazwalokacja', true, 'Błędne wywołanie aplikacji');

        
        $v = new Validator();

        $this->form->nazwalokacja = $v->validateFromPost('nazwalokacja', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj nazwę lokacji',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Nazwa powinna zawierać od 2 do 45 liter'
        ]);
        
        $this->form->wielkosc = $v->validateFromPost('wielkosc', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Wybierz skalę lokacji',
        ]);
        
        $this->form->biom = $v->validateFromPost('biom', [
            'trim' => true,
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Biom powinien zawierać od 2 do 45 liter'
        ]);
        
        return !App::getMessages()->isError();
    }
    
    public function action_lokacjaNew(){
        $this->generateView();
    }
    
    public function validateEdit() {
        $this->form->nazwalokacja = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }
    
    public function action_lokacjaEdit() {
        if ($this->validateEdit()) {
            try {
                $record = App::getDB()->get("lokacja", "*", [
                    "nazwalokacja" => $this->form->nazwalokacja
                ]);
                $this->form->nazwalokacja = $record['nazwalokacja'];
                $this->form->wielkosc = $record['wielkosc'];
                $this->form->biom = $record['biom'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        $this->generateView();
    }
    
    
    public function action_lokacjaDelete() {
        if ($this->validateEdit()) {

            try {
                App::getDB()->delete("lokacja", [
                    "nazwalokacja" => $this->form->nazwalokacja
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        App::getRouter()->forwardTo('ListaLokacji');
    }
    
    public function action_lokacjaSave() {

        if ($this->validateSave()) {
            try {
                        App::getDB()->insert("lokacja", [
                            "nazwalokacja" => $this->form->nazwalokacja,
                            "wielkosc" => $this->form->wielkosc,
                            "biom" => $this->form->biom
                        ]);
                    
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }

            App::getRouter()->forwardTo('lista_lokacji');
        } else {
            $this->generateView();
        }
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('lokacja_widok.tpl');
    }
}