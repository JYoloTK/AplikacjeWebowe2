<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use core\SessionUtils;
use app\forms\LoginForm;

class Logowanie {

    private $form;
    private $record;

    public function __construct() {
        $this->form = new LoginForm();
    }

    public function validate() {
        $this->form->login = ParamUtils::getFromRequest('login');
        $this->form->haslo = ParamUtils::getFromRequest('haslo');

       
        if (!isset($this->form->login))
            return false;

        if (empty($this->form->login)) {
            Utils::addErrorMessage('Nie podano loginu');
        }
        if (empty($this->form->haslo)) {
            Utils::addErrorMessage('Nie podano hasła');
        }

        if (App::getMessages()->isError())
            return false;
        
        $record = App::getDB()->get("user","*",["login"=>$this->form->login]);
        if ($record == NULL){Utils::addErrorMessage('Użytkownika ' . $this->form->login . ' nie ma w bazie danych');}  //przykłąd dodawania wartości php w środku stringa
        else if ($this->form->haslo != $record['haslo']){
            Utils::addErrorMessage('Niepoprawne hasło');
        } else {
        
        if ($record["rola"]=='user'){RoleUtils::addRole('user');}
        if ($record["rola"]=='admin'){RoleUtils::addRole('admin');}
        if ($record["rola"]=='GM'){RoleUtils::addRole('GM');}
        
        }
        
        
        return !App::getMessages()->isError();
    

    }

    public function action_loginShow() {
        $this->generateView();
    }

    public function action_login() {
        if ($this->validate()) {
            Utils::addErrorMessage('Poprawnie zalogowano do systemu');
            App::getRouter()->redirectTo("Hello");
        } else {
            $this->generateView();
        }
    }

    public function action_logout() {
        session_destroy();
        App::getRouter()->redirectTo('Hello');
    }

    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('logowanie_widok.tpl');
    }

}
