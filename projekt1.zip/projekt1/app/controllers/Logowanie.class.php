<?php

namespace app\controllers;

use core\App;


class Logowanie {

    public function action_logowanie(){
    App::getSmarty()->display("logowanie_widok.tpl");
    }
}
