<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ListaPotworowForm;

class TworzeniePotwora {

    private $form;

    public function __construct() {
        $this->form = new ListaPotworowForm();
    }

    public function validateSave() {
        $this->form->idpotwor = ParamUtils::getFromPost('idpotwor', true, 'Błędne wywołanie aplikacji');

        $v = new Validator();

        $this->form->rasa = $v->validateFromPost('rasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj rasę potwora',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Rasa powinna być podana od 2 do 45 liter'
        ]);
        
        $this->form->nazwalokacja = $v->validateFromPost('nazwalokacja', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj lokację, w jakiej znajduje się potwór'
        ]);
        return !App::getMessages()->isError();
    }
    
    public function action_potworNew(){
        $this->generateView();
    }
    
    public function validateEdit() {
        $this->form->idpotwor = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }
    
    public function action_potworEdit() {
        if ($this->validateEdit()) {
            try {
                $record = App::getDB()->get("potwor", "*", [
                    "idpotwor" => $this->form->idpotwor
                ]);
                $this->form->idpotwor = $record['idpotwor'];
                $this->form->rasa = $record['rasa'];
                $this->form->nazwalokacja = $record['nazwalokacja'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        $this->generateView();
    }
    
    
    public function action_potworDelete() {
        if ($this->validateEdit()) {

            try {
                App::getDB()->delete("potwor", [
                    "idpotwor" => $this->form->idpotwor
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        App::getRouter()->forwardTo('ListaPotworow');
    }
    
    public function action_potworSave() {

        if ($this->validateSave()) {
            try {

                if ($this->form->idpotwor == '') {
                    $count = App::getDB()->count("potwor");
                    if ($count <= 20) {
                        App::getDB()->insert("potwor", [
                            "rasa" => $this->form->rasa,
                            "nazwalokacja" => $this->form->nazwalokacja
                        ]);
                    } else {
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView();
                        exit();
                    }
                } else {
                    App::getDB()->update("potwor", [
                        "rasa" => $this->form->rasa,
                        "nazwalokacja" => $this->form->nazwalokacja
                            ], [
                        "idpotwor" => $this->form->idpotwor
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }
            App::getRouter()->forwardTo('lista_potworow');
        } else {
            $this->generateView();
        }
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('potwor_widok.tpl');
    }
}