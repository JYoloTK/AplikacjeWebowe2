<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ListaPotworowForm;

class TworzeniePotwora {

    private $form; //dane formularza

    public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new ListaPotworowForm();
    }

    public function validateSave() {
        //Pobranie id z walidacją czy istnieje (isset)
        $this->form->idpotwor = ParamUtils::getFromPost('idpotwor', true, 'Błędne wywołanie aplikacji');

        // Używaj ParamUtils::getFromXXX('param',true,"...") do sprawdzenia czy parametr
        // został przesłany, -  czy ISTNIEJE (isset) - może być pusty, ale jest
        
        $v = new Validator();

        $this->form->rasa = $v->validateFromPost('rasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj rasę potwora',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Rasa powinna być podana od 2 do 45 liter'
        ]);
        
        // Używaj walidatora z konfiguracją "'required' => true" aby sprawdzić,
        // czy parametr NIE JEST PUSTY (!empty)
        
        $this->form->idlokacja = $v->validateFromPost('idlokacja', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj lokację, w jakiej znajduje się potwór',
            'int' => true,
            'validator_message' => 'Lokacja powinna być liczbą całkowitą'
        ]);
        return !App::getMessages()->isError();
    }
    
    public function action_potworNew(){
        $this->generateView();
    }
    
    public function action_potworSave() {

        // 1. Walidacja danych formularza (z pobraniem)
        if ($this->validateSave()) {
            // 2. Zapis danych w bazie
            try {

                //2.1 Nowy rekord
                if ($this->form->idpotwor == '') {
                    //sprawdź liczebność rekordów - nie pozwalaj przekroczyć 20
                    $count = App::getDB()->count("potwor");
                    if ($count <= 20) {
                        App::getDB()->insert("potwor", [
                            "rasa" => $this->form->rasa,
                            "idlokacja" => $this->form->idlokacja
                        ]);
                    } else { //za dużo rekordów
                        // Gdy za dużo rekordów to pozostań na stronie
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView(); //pozostań na stronie edycji
                        exit(); //zakończ przetwarzanie, aby nie dodać wiadomości o pomyślnym zapisie danych
                    }
                } else {
                    //2.2 Edycja rekordu o danym ID
                    App::getDB()->update("potwor", [
                        "rasa" => $this->form->rasa,
                        "idlokacja" => $this->form->idlokacja
                            ], [
                        "idpotwor" => $this->form->idpotwor
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }

            // 3b. Po zapisie przejdź na stronę listy osób (w ramach tego samego żądania http)
            App::getRouter()->forwardTo('lista_potworow');
        } else {
            // 3c. Gdy błąd walidacji to pozostań na stronie
            $this->generateView();
        }
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form); // dane formularza dla widoku
        App::getSmarty()->display('potwor_widok.tpl');
    }
}