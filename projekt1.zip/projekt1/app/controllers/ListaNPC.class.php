<?php

namespace app\controllers;
use core\App;
use app\forms\ListaNPCForm;

class ListaNPC {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->form = new ListaNPCForm();
    }
        
  public function action_lista_npc() {
      
      
        try {
            $this->records = App::getDB()->select("npc", [
                "idnpc",
                "nazwa",
                "rasa",
                "idlokacja",
                    ]);
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas pobierania rekordów');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }
      
      
      
    $records = App::getDB()->select("npc", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("npc_lista_widok.tpl");
  }
  
}