<?php

namespace app\controllers;
use core\App;
use app\forms\ListaLokacjiForm;

class ListaLokacji {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		$this->form = new ListaLokacjiForm();
    }
        
  public function action_lista_lokacji() {
      
      
        try {
            $this->records = App::getDB()->select("lokacja", [
                "nazwalokacja",
                "wielkosc",
                "biom",
                    ]);
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas pobierania rekordów');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }
      
      
    $records = App::getDB()->select("lokacja", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("lokacja_lista_widok.tpl");
  }
  
}