<?php

namespace app\controllers;
use core\App;
use app\forms\ListaLokacjiForm;

class ListaLokacji {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->form = new ListaLokacjiForm();
    }
        
  public function action_lista_lokacji() {
    $records = App::getDB()->select("lokacja", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("lokacja_lista_widok.tpl");
  }
  
}