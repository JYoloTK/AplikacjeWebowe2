<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use core\SessionUtils;
use app\forms\ListaPostaciForm;
use app\forms\ListaLokacjiForm;

class TworzeniePostaci {

    private $form;
    private $form2;
    private $records;

    public function __construct() {
        $this->form = new ListaPostaciForm();
        $this->form2 = new ListaLokacjiForm();
    }

    public function validateSave() {
        $this->form->idpostac = ParamUtils::getFromPost('idpostac', true, 'Błędne wywołanie aplikacji');

        $v = new Validator();
        
        $this->form->nazwa = $v->validateFromPost('nazwa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj nazwę postaci',
            'min_length' => 1,
            'max_length' => 45,
            'validator_message' => 'Nazwa powinna zawierać od 1 do 45 liter'
        ]);

        $this->form->rasa = $v->validateFromPost('rasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj rasę postaci',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Rasa powinna zawierać od 2 do 45 liter'
        ]);
        
        $this->form->klasa = $v->validateFromPost('klasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj klasę postaci',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Klasa powinna zawierać od 2 do 45 liter'
        ]);
        
        $this->form->level = $v->validateFromPost('level', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj level postaci',
            'int' => true,
            'validator_message' => 'Level powinien być liczbą całkowitą'
        ]);
        
        $this->form->wiek = $v->validateFromPost('wiek', [
            'trim' => true,
            'int' => true,
            'validator_message' => 'Wiek powinien być liczbą całkowitą'
        ]);
        
        $this->form->nazwalokacja = $v->validateFromPost('nazwalokacja', [
            'trim' => true,
        ]);
        
        $this->form->login = $v->validateFromPost('login', [
            'trim' => true,
        ]);
        
        return !App::getMessages()->isError();
    }
    
    public function action_postacNew(){
        $this->generateView();
    }
    
    public function validateEdit() {
        $this->form->idpostac = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }
    
    public function action_postacEdit() {
        if ($this->validateEdit()) {
            try {
                $record = App::getDB()->get("postac", "*", [
                    "idpostac" => $this->form->idpostac
                ]);
                $this->form->idpostac = $record['idpostac'];
                $this->form->nazwa = $record['nazwa'];
                $this->form->rasa = $record['rasa'];
                $this->form->klasa = $record['klasa'];
                $this->form->level = $record['level'];
                $this->form->wiek = $record['wiek'];
                $this->form->nazwalokacja = $record['nazwalokacja'];
                $this->form->login = $record['login'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        $this->generateView();
    }
    
    public function action_postacDelete() {
        if ($this->validateEdit()) {

            try {
                App::getDB()->delete("postac", [
                    "idpostac" => $this->form->idpostac
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        App::getRouter()->forwardTo('ListaPostaci');
    }
    
    public function action_postacSave() {

        if ($this->validateSave()) {
            try {

                //2.1 Nowy rekord
                if ($this->form->idpostac == '') {
                    $count = App::getDB()->count("postac");
                    if ($count <= 20) {
                        App::getDB()->insert("postac", [
                            "nazwa" => $this->form->nazwa,
                            "rasa" => $this->form->rasa,
                            "klasa" => $this->form->klasa,
                            "level" => $this->form->level,
                            "wiek" => $this->form->wiek,
                            "nazwalokacja" => $this->form->nazwalokacja,
                            "login" => SessionUtils::load('username',$keep=true),
                        ]);
                    } else {
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView();
                        exit();
                    }
                } else {
                    App::getDB()->update("postac", [
                        "nazwa" => $this->form->nazwa,
                        "rasa" => $this->form->rasa,
                        "klasa" => $this->form->klasa,
                        "level" => $this->form->level,
                        "wiek" => $this->form->wiek,
                        "nazwalokacja" => $this->form->nazwalokacja,
                        "login" => SessionUtils::load('username',$keep=true)
                            ], [
                        "idpostac" => $this->form->idpostac
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }

            App::getRouter()->forwardTo('lista_postaci');
        } else {
            $this->generateView();
        }
    }   
    
    public function action_postacLokacja(){
                try {
            $this->records = App::getDB()->select("lokacja", [
                "nazwalokacja",
                "wielkosc",
                "biom",
                    ]);
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas pobierania rekordów');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }
      
    $records = App::getDB()->select("lokacja", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("lokacja_postac_widok.tpl");
    }

    public function action_wybierzLokacja(){
        $this->form->nazwalokacja = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        try{
        $record = App::getDB()->get("lokacja", "*", [
            "nazwalokacja" => $this->form->nazwalokacja
            ]);
        $this->nazwalokacja = $record['nazwalokacja'];
        } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        $this->generateView();
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('postac_widok.tpl');
    }
}