<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ListaPostaciForm;

class TworzeniePostaci {

    private $form; //dane formularza

    public function __construct() {
        //stworzenie potrzebnych obiektów
        $this->form = new ListaPostaciForm();
    }

    public function validateSave() {
        //Pobranie id z walidacją czy istnieje (isset)
        $this->form->idpostac = ParamUtils::getFromPost('idpostac', true, 'Błędne wywołanie aplikacji');

        // Używaj ParamUtils::getFromXXX('param',true,"...") do sprawdzenia czy parametr
        // został przesłany, -  czy ISTNIEJE (isset) - może być pusty, ale jest
        
        $v = new Validator();
        
        $this->form->nazwa = $v->validateFromPost('nazwa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj nazwę postaci',
            'min_length' => 1,
            'max_length' => 45,
            'validator_message' => 'Nazwa powinna zawierać od 1 do 45 liter'
        ]);

        $this->form->rasa = $v->validateFromPost('rasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj rasę postaci',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Rasa powinna zawierać od 2 do 45 liter'
        ]);
        
        $this->form->klasa = $v->validateFromPost('klasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj klasę postaci',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Klasa powinna zawierać od 2 do 45 liter'
        ]);
        
        $this->form->level = $v->validateFromPost('level', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj level postaci',
            'int' => true,
            'validator_message' => 'Level powinien być liczbą całkowitą'
        ]);
        
        $this->form->wiek = $v->validateFromPost('wiek', [
            'trim' => true,
            'int' => true,
            'validator_message' => 'Wiek powinien być liczbą całkowitą'
        ]);
        
        $this->form->idlokacja = $v->validateFromPost('idlokacja', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj id lokacji, w jakiej znajduje się potwór',
            'int' => true,
            'validator_message' => 'Id lokacji powinno być liczbą całkowitą'
        ]);
        
        $this->form->idlokacja = $v->validateFromPost('iduser', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj id użytkownika, do którego należy postać',
            'int' => true,
            'validator_message' => 'Id użytkownika powinno być liczbą całkowitą'
        ]);
        return !App::getMessages()->isError();
    }
    
    public function action_postacNew(){
        $this->generateView();
    }
    
    public function action_postacSave() {

        // 1. Walidacja danych formularza (z pobraniem)
        if ($this->validateSave()) {
            // 2. Zapis danych w bazie
            try {

                //2.1 Nowy rekord
                if ($this->form->idpostac == '') {
                    //sprawdź liczebność rekordów - nie pozwalaj przekroczyć 20
                    $count = App::getDB()->count("postac");
                    if ($count <= 20) {
                        App::getDB()->insert("postac", [
                            "nazwa" => $this->form->nazwa,
                            "rasa" => $this->form->rasa,
                            "klasa" => $this->form->klasa,
                            "level" => $this->form->level,
                            "wiek" => $this->form->wiek,
                            "idlokacja" => $this->form->idlokacja,
                            "iduser" => $this->form->iduser
                        ]);
                    } else { //za dużo rekordów
                        // Gdy za dużo rekordów to pozostań na stronie
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView(); //pozostań na stronie edycji
                        exit(); //zakończ przetwarzanie, aby nie dodać wiadomości o pomyślnym zapisie danych
                    }
                } else {
                    //2.2 Edycja rekordu o danym ID
                    App::getDB()->update("postac", [
                        "nazwa" => $this->form->nazwa,
                        "rasa" => $this->form->rasa,
                        "klasa" => $this->form->klasa,
                        "level" => $this->form->level,
                        "wiek" => $this->form->wiek,
                        "idlokacja" => $this->form->idlokacja,
                        "iduser" => $this->form->iduser
                            ], [
                        "idpostac" => $this->form->idpostac
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }

            // 3b. Po zapisie przejdź na stronę listy osób (w ramach tego samego żądania http)
            App::getRouter()->forwardTo('lista_postaci');
        } else {
            // 3c. Gdy błąd walidacji to pozostań na stronie
            $this->generateView();
        }
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form); // dane formularza dla widoku
        App::getSmarty()->display('postac_widok.tpl');
    }
}