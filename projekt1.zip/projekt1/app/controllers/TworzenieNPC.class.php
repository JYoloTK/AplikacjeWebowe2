<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\ListaNPCForm;

class TworzenieNPC {

    private $form; //dane formularza

    public function __construct() {
        $this->form = new ListaNPCForm();
    }

    public function validateSave() {
        $this->form->idnpc = ParamUtils::getFromPost('idnpc', true, 'Błędne wywołanie aplikacji');

        $v = new Validator();

        $this->form->nazwa = $v->validateFromPost('nazwa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj nazwę npc',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Nazwa powinna być podana od 2 do 45 liter'
        ]);
        
        $this->form->rasa = $v->validateFromPost('rasa', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj rasę npc',
            'min_length' => 2,
            'max_length' => 45,
            'validator_message' => 'Rasa powinna być podana od 2 do 45 liter'
        ]);

        
        $this->form->nazwalokacja = $v->validateFromPost('nazwalokacja', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Podaj lokację, w jakiej znajduje się npc'
        ]);
        return !App::getMessages()->isError();
    }
    
    public function action_npcNew(){
        $this->generateView();
    }
    
    public function validateEdit() {
        $this->form->idnpc = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }
    
    public function action_npcEdit() {
        if ($this->validateEdit()) {
            try {
                $record = App::getDB()->get("npc", "*", [
                    "idnpc" => $this->form->idnpc
                ]);
                $this->form->idnpc = $record['idnpc'];
                $this->form->nazwa = $record['nazwa'];
                $this->form->rasa = $record['rasa'];
                $this->form->nazwalokacja = $record['nazwalokacja'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        $this->generateView();
    }
    
    
    public function action_npcDelete() {
        if ($this->validateEdit()) {

            try {
                App::getDB()->delete("npc", [
                    "idnpc" => $this->form->idnpc
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }
        App::getRouter()->forwardTo('ListaNPC');
    }
    
    public function action_npcSave() {

        if ($this->validateSave()) {
            try {

                //2.1 Nowy rekord
                if ($this->form->idnpc == '') {
                    $count = App::getDB()->count("npc");
                    if ($count <= 20) {
                        App::getDB()->insert("npc", [
                            "nazwa" => $this->form->nazwa,
                            "rasa" => $this->form->rasa,
                            "nazwalokacja" => $this->form->nazwalokacja
                        ]);
                    } else {
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView();
                        exit();
                    }
                } else {
                    App::getDB()->update("npc", [
                        "nazwa" => $this->form->nazwa,
                        "rasa" => $this->form->rasa,
                        "nazwalokacja" => $this->form->nazwalokacja
                            ], [
                        "idnpc" => $this->form->idnpc
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
                if (App::getConf()->debug){
                    Utils::addErrorMessage($e->getMessage());
                }
            }

            App::getRouter()->forwardTo('lista_npc');
        } else {
            $this->generateView();
        }
    }
    
    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('npc_widok.tpl');
    }
}
