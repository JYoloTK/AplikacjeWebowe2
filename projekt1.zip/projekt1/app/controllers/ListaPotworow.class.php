<?php

namespace app\controllers;
use core\App;
use app\forms\ListaPotworowForm;

class ListaPotworow {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->form = new ListaPotworowForm();
    }
        
  public function action_lista_potworow() {
    $records = App::getDB()->select("potwor", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("potwor_lista_widok.tpl");
  }
  
}