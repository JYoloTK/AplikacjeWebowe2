<?php

namespace app\controllers;
use core\App;
use app\forms\ListaPostaciForm;

class ListaPostaci {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		$this->form = new ListaPostaciForm();
    }
        
  public function action_lista_postaci() {
      
    try {
            $this->records = App::getDB()->select("postac", [
                "idpostac",
                "nazwa",
                "rasa",
                "klasa",
                "level",
                "wiek",
                "login",
                "idlokacja"
                    ]);
    } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas pobierania rekordów');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
    }
      
    $records = App::getDB()->select("postac", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("postac_lista_widok.tpl");
  }
  
}