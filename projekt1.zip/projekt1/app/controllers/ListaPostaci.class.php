<?php

namespace app\controllers;
use core\App;
use app\forms\ListaPostaciForm;

class ListaPostaci {

    private $form; //dane formularza
    private $records; //rekordy pobrane z bazy danych

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->form = new ListaPostaciForm();
    }
        
  public function action_lista_postaci() {
    $records = App::getDB()->select("postac", "*");
    App::getSmarty()->assign("lista",$this->records);
    App::getSmarty()->display("postac_lista_widok.tpl");
  }
  
}