<?php

namespace app\forms;

class ListaLokacjiForm {
	public $idlokacja;
	public $nazwa;
	public $wielkosc;
	public $biom;
}