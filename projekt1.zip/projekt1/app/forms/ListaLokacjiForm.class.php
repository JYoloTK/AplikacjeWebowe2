<?php

namespace app\forms;

class ListaLokacjiForm {
	public $nazwalokacja;
	public $wielkosc;
	public $biom;
}