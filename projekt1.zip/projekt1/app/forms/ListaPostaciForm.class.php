<?php

namespace app\forms;

class ListaPostaciForm {
	public $idpostac;
	public $nazwa;
	public $rasa;
	public $klasa;
        public $level;
        public $wiek;
        public $login;
        public $nazwalokacja;
}