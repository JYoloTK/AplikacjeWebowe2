<?php

namespace app\forms;

class ListaNPCForm {
	public $idnpc;
	public $nazwa;
	public $rasa;
        public $idlokacja;
}