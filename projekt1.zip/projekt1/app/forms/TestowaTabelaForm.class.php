<?php

namespace app\forms;

class TestowaTabelaForm {
	public $iduser;
	public $login;
	public $haslo;
	public $rola;
}