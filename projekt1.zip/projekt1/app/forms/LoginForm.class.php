<?php

namespace app\forms;

class LoginForm {
	public $login;
        public $haslo;
        public $rola;
}