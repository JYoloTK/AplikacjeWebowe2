<?php

namespace app\forms;

class ListaPotworowForm {
	public $idpotwor;
	public $rasa;
        public $nazwalokacja;
}